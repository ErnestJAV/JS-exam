/* ------------------------------ TASK 1 ----------------------------
Parašykite JS kodą, kuris leis vartotojui įvesti svorį kilogramais ir
pamatyti jo pateikto svorio kovertavimą į:
1. Svarus (lb) | Formulė: lb = kg * 2.2046
2. Gramus (g) | Formulė: g = kg / 0.0010000
3. Uncijos (oz) | Formul4: oz = kg * 35.274

Pastaba: atvaizdavimas turi būti matomas pateikus formą ir pateikiamas
<div id="output"></div> viduje, bei turi turėti bent minimalų stilių;
------------------------------------------------------------------- */




const el = document.getElementById("add");

const For_output = document.getElementById("output");

el.addEventListener("submit", (event)=>{event.preventDefault()

    let input = document.getElementById("search").value;
    
    Svarus = input * 2.2046
    Gramus = input / 0.0010000
    Uncijos  =  input * 35.274

    For_output.textContent = `Svarai - ${Svarus}, Gramai - ${Gramus}, Uncijos - ${Uncijos} `
    For_output.style.color = 'red';
    For_output.style.border = "solid";
    For_output.style.textAlign = "Center"
    For_output.style.margin = "10rem 10rem"





    console.log(Svarus)

})

